let listItems = fliterdSuggetopns.map(pokemon =>
    $("#suggestions").append(
        `<li data-id="${pokemon.id}">pokemon.pokemon</li>`
    )

);

fliterdSuggetopns.forEach(function(pokemon){
    $("#suggestions").append(
        `<li data-id="${pokemon.id}">pokemon.pokemon</li>`
    )
})

$(doument).on('click',"#suggestions li",function(){
    let pokemonId = $(this).data("id");
    let selectedPokemon = pokemonData.find(function(pokemon){
        return pokemon.id === pokemonId

    })
})

data.forEach(function (pokemon) {
    pokemon.abilities.forEach(function (ability) {
      abilitiesSet.add(ability);
    });
  });

data.reduce((set,pokemon) =>{
    pokemon.abilities.forEach(ability => set.add(ability));
    return set;
  }, abilitiesSet);

  abilitiesArray.forEach(function(ability){
  let label = $('<label><input type="checkbox" value="' + ability + '" class="ability-checkbox"> ' + ability + "</label>");
  toggleAbilitiesDropdown.appemd(label);
  })

  let lable = abilitiesArray.map(ability =>
    `<label><input type="checkbox" value="${ability}" class="ability-checkbox"> ${ability}</label>`


  ).join("")
toggleAbilitiesDropdown.append(label);

data.forEach(function(pokemon){
    let typeSet = new Set();
    data.forEach(function(type){
        typeSet.add(type.trim())
    })
})

data.forEach(pokemon => {
    let typeSet = new Set(pokemon.types.map(type => type.trim()));
  });

  data.forEach(pokemon => {
    let typeSet = pokemon.types.reduce((set, type) => {
      set.add(type.trim());
      return set;
    }, new Set());
  });
  

  ? pokemon.type.split("/").map((t) => 
    t.trim().toLowerCase()).includes(selectedType.toLowerCase())
  : true;

  types.forEach(function(type) {
    $("#pokemonTypeFilter").append(
      `<option value="${type}">${type.charAt(0).toUpperCase() + type.slice(1)}</option>`
    );
  });

  
  const options = types.map(function(type) {
    return `<option value="${type}">${type.charAt(0).toUpperCase() + type.slice(1)}</option>`;
  }).join('');
  
  $("#pokemonTypeFilter").append(options);

  data.forEach(function (pokemon) {
    let types = pokemon.type.split("/");
    types.forEach((type) => {
      typesSet.add(type.trim());
    });
  })

  for (let pokemon of data){
    

    let types = pokemon.types.split('/')
    for (let type of types){
      typeSet.add(type.trim())
    }

  }
  typeArray.forEach(function (type) {
    $("#pokemonTypeFilter").append(
      new Option(type.charAt(0).toUpperCase() + type.slice(1), type)
    );
  });

  typeArray.map((type) =>
    $("#pokemonTypeFilter").append(
      new Option(type.charAt(0).toUpperCase() +type.slice(1),type).join(", ")
    )
  )

  const types = pokemon.type.split("/");
for (let i = 0; i < types.length; i++) {
  if (types[i].trim().toLowerCase() === selectedType.toLowerCase()) {
    return true;
  }
}
return false;

? types.map((t) => 
  t.trim().toLowerCase()).includes(selectedType.toLowerCase())
: true;


let matchesAbilities = selectedAbilities.length
      ? selectedAbilities.every((ability) =>
        // Convert abilities to lowercase for comparison
        pokemon.abilities.map(a => a.toLowerCase()).includes(ability)) 
      : true;


for (let i = 0; i < selectedAbilities.length; i++){
  if (pokemon.abilities.includes(selectedAbilities[i])){
    return true
    }
    }

    


}
  



