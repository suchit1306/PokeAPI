// Global variables
let pokemonData = [];
let dataTableInstance = null;

// Fetch Pokémon data from the API
function fetchPokemonData() {
  $.get("https://dummyapi.online/api/pokemon")
    .done(function (data) {
      console.log("API Response:", data);
      pokemonData = data; // Store Pokémon data
      populateTable(pokemonData); // Dynamically populate the table
      populateAbilitiesFilter(pokemonData); // Dynamically populate abilities filter
      populateTypeFilter(pokemonData); // Dynamically populate type filter
    })
    .fail(function (xhr, status, error) {
      console.error("Request failed. Status: " + status + ". Error: " + error);
      $("#pokemon-table-container").html("<p>Failed to load Pokémon data.</p>");
    });
}

// Function to truncate text if it exceeds 25 characters and apply tooltip
function truncateText(text) {
  if (text.length > 25) {
    return text.substring(0, 15) + "..."; // Truncate to 15 characters with ellipsis
  }
  return text;
}

// Function to add tooltip for full text
function applyTooltip(element, text) {
 
  if (text.length > 25) {
    element.attr("title", text); // Set full text as title
  }
}

// Function to show a pop-up message
function showPopup(message) {
  $("#popup-message").text(message); // Set the message text inside the pop-up
  $("#popup").fadeIn(); // Show the pop-up with a fade-in effect
}
 
// Function to close the pop-up
$("#close-popup").click(function () {
  $("#popup").fadeOut(); // Hide the pop-up with a fade-out effect
});

// Function to dynamically create and populate the table
function populateTable(data) {
  // Check if DataTable is already initialized
  if ($.fn.dataTable.isDataTable("#pokemonTable")) {
    let table = $("#pokemonTable").DataTable();
    table.clear(); // Clear the table
    table.rows.add(
      data.map((pokemon) => [
        pokemon.id,
        `<span class="pokemon-name">${truncateText(pokemon.pokemon)}</span>`,
        `<span class="pokemon-type">${truncateText(pokemon.type)}</span>`,
        `<span class="pokemon-abilities">${truncateText(
          pokemon.abilities.join(", ")
        )}</span>`,
        `<img src="${pokemon.image_url}" alt="${pokemon.pokemon}" width="50" height="50">`,
        `<button class="edit-btn" data-id="${pokemon.id}">Edit</button><button class="delete-btn" data-id="${pokemon.id}">Delete</button>`,
      ])
    );
    table.draw();
    return;
  }

  let table = $('<table id="pokemonTable" class="display" style="width:100%"></table>');
  let thead = $("<thead><tr><th>ID</th><th>Name</th><th>Type</th><th>Abilities</th><th>Image</th><th>Actions</th></tr></thead>");
  let tbody = $("<tbody></tbody>");

  table.append(thead).append(tbody);
  $("#pokemon-table-container").append(table);

  data.forEach(function (pokemon) {
    let abilitiesList = pokemon.abilities.join(", ");
    let row = $('<tr data-id="' + pokemon.id + '"></tr>');
    row.append("<td>" + pokemon.id + "</td>");
    row.append("<td>" + pokemon.pokemon + "</td>");
    row.append("<td>" + pokemon.type + "</td>");
    row.append("<td>" + abilitiesList + "</td>");
    row.append('<td><img src="' + pokemon.image_url + '" alt=" No image found" width="50" height="50"></td>');
    row.append('<td><button class="edit-btn" data-id="' + pokemon.id + '">Edit</button><button class="delete-btn" data-id="' + pokemon.id + '">Delete</button></td>');
    tbody.append(row);

    applyTooltip(row.find(".pokemon-name"), pokemon.pokemon);
    applyTooltip(row.find(".pokemon-type"), pokemon.type);
    applyTooltip(row.find(".pokemon-abilities"), abilitiesList);
  });

  dataTableInstance = $("#pokemonTable").DataTable({
    dom: "Bfrtip",
    paging: true,
    searching: true,
    ordering: true,
    info: true,
    responsive: true,
    pagingType: "simple_numbers",
   columnDefs: [
      {
        targets: [4, 5],
        orderable: false,
      },
    ],
    buttons: [
      {
        extend: "excelHtml5",
        text: "Export to Excel",
        className: "btn btn-primary",
        title: "Pokémon Data",
        exportOptions: {
          columns: [0, 1, 2, 3],
        },
      },
      {
        extend: "pdfHtml5",
        text: "Export to PDF",
        className: "btn btn-primary",
        title: "Pokémon Data",
        exportOptions: {
          columns: [0, 1, 2, 3],
        },
      },
    ],
    initComplete: function () {
      // var searchInput = $(".dataTables_filter input");
      // $(".nav-search").append(searchInput);
      $(".nav-search input").css({
        width: "80%",
        padding: "8px",
        borderRadius: "4px",
        border: "1px solid #ccc",
        fontSize: "16px",
      });
      $(".dataTables_filter label").hide();
      // Move the search box into your nav-search container

       // Handle change in number of entries to display
       $("#entries").on("change", function () {
        const length = $(this).val();
        dataTableInstance.page.len(length).draw();
      });


      var searchInput = $(".dataTables_filter input");
      $(".nav-search").append(searchInput); // Append it to your nav-search container
      searchInput.attr("placeholder", "Search Pokémon..."); // Customize the placeholder text

      // Handle search input and show suggestions
      $(".nav-search").on("input", "input", function () {
        let query = $(this).val().toLowerCase();

        // Filter suggestions based on the input query
        let filteredSuggestions = pokemonData.filter(function (pokemon) {
          return pokemon.pokemon.toLowerCase().includes(query);
        });

        // Clear the previous suggestions
        $("#suggestions").empty();

        // Show filtered suggestions
        filteredSuggestions.forEach(function (pokemon) {
          $("#suggestions").append(
            '<li data-id="' + pokemon.id + '">' + pokemon.pokemon + "</li>"
          );
        });

        // Show suggestions list if there's any query
        if (query && filteredSuggestions.length > 0) {
          $("#suggestions").show();
        } else {
          $("#suggestions").hide();
        }
      });

      // When a suggestion is clicked, update the table
      $(document).on("click", "#suggestions li", function () {
        let pokemonId = $(this).data("id");
        let selectedPokemon = pokemonData.find(function (pokemon) {
          return pokemon.id === pokemonId;
        });

        if (selectedPokemon) {
          // Filter the table based on the selected Pokémon
          let table = $("#pokemonTable").DataTable();
          table.search(selectedPokemon.pokemon).draw();
        }

        // Hide the suggestions after selection
        $("#suggestions").hide();
      });

      // Close suggestions when clicking outside
      $(document).on("click", function (e) {
        if (!$(e.target).closest(".nav-search").length) {
          $("#suggestions").hide(); // Hide suggestions when clicking outside
        }
      });
    },
  });

  // Event listener for Edit button click
  $(document).on("click", ".edit-btn", function () {
   
    let pokemonId = $(this).data("id");
    let selectedPokemon = pokemonData.find(function (pokemon) {
      return pokemon.id === pokemonId;
    });
    
    if (selectedPokemon) {
      openEditModal(selectedPokemon);
    }
  });
    // Event listener for Delete button click
    $(document).on("click", ".delete-btn", function () {
      let pokemonId = $(this).data("id");
      deleteRow(pokemonId);
    });

  $("#export-to-excel").click(function () {
    dataTableInstance.button(0).trigger();
    showPopup("Export Data Succesfully!");
  });
  $("#export-to-pdf").click(function () {
    dataTableInstance.button(1).trigger();
    showPopup("Export Data Succesfully!");
  });
}


// Function to dynamically populate the abilities filter with checkboxes
function populateAbilitiesFilter(data) {
  let abilitiesSet = new Set();
  data.forEach(function (pokemon) {
    pokemon.abilities.forEach(function (ability) {
      abilitiesSet.add(ability);
    });
  });
  let abilitiesArray = Array.from(abilitiesSet).sort();
  let abilitiesDropdown = $("#abilitiesDropdown");
  abilitiesDropdown.empty();

  abilitiesArray.forEach(function (ability) {
    let label = $('<label><input type="checkbox" value="' + ability + '" class="ability-checkbox"> ' + ability + "</label>");
    abilitiesDropdown.append(label);
  });
}

// Function to dynamically populate the type filter dropdown
function populateTypeFilter(data) {
  let typesSet = new Set();
  data.forEach(function (pokemon) {
    let types = pokemon.type.split("/");
    types.forEach((type) => {
      typesSet.add(type.trim());
    });
  });
  let typeArray = Array.from(typesSet).sort();
  typeArray.forEach(function (type) {
    $("#pokemonTypeFilter").append(
      new Option(type.charAt(0).toUpperCase() + type.slice(1), type)
    );
  });
}

// Handle Pokémon Type Dropdown change event
function handleTypeFilterChange() {
  filterTable();
}

// Handle Pokémon Abilities Checkbox change event
function handleAbilityCheckboxChange() {

  filterTable();
}

// Function to filter the table based on selected type and abilities
function filterTable() {
  let selectedType = $("#pokemonTypeFilter").val();
  let selectedAbilities = [];

  $(".ability-checkbox:checked").each(function () {
    selectedAbilities.push($(this).val().toLowerCase());
  });

  let filteredData = pokemonData.filter(function (pokemon) {
    let matchesType = selectedType
      ? pokemon.type.split("/").map((t) => 
        t.trim().toLowerCase()).includes(selectedType.toLowerCase())
      : true;

    let matchesAbilities = selectedAbilities.length
      ? selectedAbilities.every((ability) =>
        // Convert abilities to lowercase for comparison
        pokemon.abilities.map(a => a.toLowerCase()).includes(ability)) 
      : true;

    return matchesType && matchesAbilities;
  });

  populateTable(filteredData);
}

// Add Row Modal
function addRowModal() {
  $("#new-name").val("");
  $("#new-type").val("");
  $("#new-abilities").val("");
  $("#new-image-url").val("");
  $("#add-row-modal").show();
}

// Toggle the dropdown visibility for abilities
function toggleAbilitiesDropdown() {
  $(".dropdown-menu").toggle();
  $(".ability-checkbox").on("change", handleAbilityCheckboxChange);
}

// Save the new Pokémon when the "Save" button is clicked
function saveNewPokemon() {
  let name = $("#new-name").val().trim();
  let type = $("#new-type").val().trim();
  let abilities = $("#new-abilities").val().split(",");
  let imageUrl = $("#new-image-url").val().trim();

  if (!name || !type || !abilities.length || !imageUrl) {
    showPopup("Please fill out all the fields!");
    return;
  }

  let newId =
        pokemonData.reduce(function (maxId, pokemon) {
          return Math.max(maxId, pokemon.id);
        }, 0) + 1;
  // Add the new Pokémon to the data array
  let newPokemon = {
    id: newId,
    pokemon: name,
    type: type,
    abilities: abilities,
    image_url: imageUrl,
  };

  pokemonData.unshift(newPokemon);
  // populateTable(pokemonData); // Re-populate the table with updated data


  // Dynamically add the new types to the type filter dropdown if not already present
  let types = type.split("/"); // Split the type by "/"
  // Loop through all the types of the new Pokémon
  types.forEach(function (type) {
    let trimmedType = type.trim().toLowerCase(); // Trim and convert to lowercase
    // Check if the type already exists in the dropdown (case-insensitive)
    let exists = false;
    $("#pokemonTypeFilter option").each(function () {
      if ($(this).val().toLowerCase() === trimmedType) {
        exists = true;
        return false; // Exit the loop if the type already exists
      }
    });
    // If the type doesn't exist, append it to the dropdown
    if (!exists) {
      $("#pokemonTypeFilter").append(
        new Option(type.charAt(0).toUpperCase() + type.slice(1), trimmedType)
      );
    }
  });

  // Dynamically add the new abilities to the abilities filter dropdown if not already present
abilities.forEach(function (ability) {
let abilityLower = ability.toLowerCase().trim(); // Convert ability to lowercase and trim to handle any leading/trailing spaces

// Collect existing abilities from the dropdown and check if this ability is already present
let existingAbilities = $("#abilitiesDropdown .ability-checkbox").map(function () {
  return $(this).val().toLowerCase().trim(); // Get the value of each checkbox, lowercase and trimmed
}).get(); // Convert the jQuery object to an array

// Only append the ability if it does not already exist
if (!existingAbilities.includes(abilityLower)) {
  let label = $(
    `<label><input type="checkbox" value="${abilityLower}"
     class="ability-checkbox"> ${ability.charAt(0).toUpperCase() + 
      ability.slice(1)}</label>`
  );
  $("#abilitiesDropdown").append(label); // Append the new ability if it's not already present
}
});
   // After adding the Pokémon, we want to prepend the row to the table.
  let table = $("#pokemonTable").DataTable();
  let row = table.row.add([
    newPokemon.id,
    `<span class="pokemon-name">${truncateText(newPokemon.pokemon)}</span>`,
    `<span class="pokemon-type">${truncateText(newPokemon.type)}</span>`,
    `<span class="pokemon-abilities">${truncateText(newPokemon.abilities.join(", "))}</span>`,
    `<img src="${newPokemon.image_url}" alt="${newPokemon.pokemon}" width="50" height="50">`,
    `<button class="edit-btn" data-id="${newPokemon.id}">Edit</button><button class="delete-btn" data-id="${newPokemon.id}">Delete</button>`,
  ]).draw(false); // The 'draw(false)' ensures the table is updated, but we don't reset the pagination.

  // Prepend the newly added row to the first position
$(table.row(row.index()).node()).prependTo("#pokemonTable tbody");


  $("#add-row-modal").hide();
  showPopup("Row Added successfully");
}

// Function to cancel the "Add Row" modal
function cancelAddRowModal() {
  $("#add-row-modal").hide();
}
function openEditModal(pokemon) {
  // Set the values in the edit modal
  $("#edit-name").val(pokemon.pokemon);
  $("#edit-type").val(pokemon.type);
  $("#edit-abilities").val(pokemon.abilities.join(", "));
  $("#edit-image-url").val(pokemon.image_url);
  $("#edit-row-modal").data("pokemonId", pokemon.id); // Store Pokémon ID in the modal for later use
  $("#edit-row-modal").show();
}

// Save edited Pokémon
$("#save-edited-row").on("click", function () {

  // Function to show the custom modal
  function showCustomModal() {
    document.getElementById('customModal').style.display = 'block';
    $("#modalMessage").text("Are you sure you want to edit this Pokémon?");
  }

  
  // Function to hide the custom modal
  function hideCustomModal() {
    document.getElementById('customModal').style.display = 'none';
    
  }
  
  // Event listeners for buttons
  document.getElementById('yesButton').addEventListener('click', function() {
    console.log("User clicked Yes.");
    hideCustomModal();
    // Proceed with the delete operation
    
  let pokemonId = $("#edit-row-modal").data("pokemonId");
  let name = $("#edit-name").val().trim();
  let type = $("#edit-type").val().trim();
  let abilities = $("#edit-abilities").val().split(",");
  let imageUrl = $("#edit-image-url").val();

  if (!name || !type || !abilities.length || !imageUrl) {
    showPopup("Please fill out all the fields!");
    return;
  }
  let editedData = {
    pokemon: name,
    type: type,
    abilities: abilities,
    image_url: imageUrl,
  };

  saveEditedPokemon(pokemonId, editedData);
  $("#edit-row-modal").hide(); // Close the modal after saving
  showPopup("Edited row Succesfully!")
  });
  
  document.getElementById('noButton').addEventListener('click', function() {
    console.log("User clicked No.");
    hideCustomModal();
    $("#edit-row-modal").hide();
    // Handle cancellation
  });
  // Trigger the custom modal
  showCustomModal();
  
});

// Function to save edited Pokémon
function saveEditedPokemon(pokemonId, editedData) {
  let pokemon = pokemonData.find((p) => p.id === pokemonId);
  if (pokemon) {
    pokemon.pokemon = editedData.pokemon;
    pokemon.type = editedData.type;
    pokemon.abilities = editedData.abilities;
    pokemon.image_url = editedData.image_url;
    populateTable(pokemonData); // Re-populate the table with updated data
  }
}


// Function to delete a Pokémon row
function deleteRow(pokemonId) {
  // Function to show the custom modal
function showCustomModal() {
  document.getElementById('customModal').style.display = 'block';
}

// Function to hide the custom modal
function hideCustomModal() {
  document.getElementById('customModal').style.display = 'none';
}

// Event listeners for buttons
document.getElementById('yesButton').addEventListener('click', function() {
  console.log("User clicked Yes.");
  hideCustomModal();
  // Proceed with the delete operation
  pokemonData = pokemonData.filter((p) => p.id !== pokemonId);
  filterTable(); // Reapply filters after deletion to keep the table in the same filtered state
  showPopup("Row deleted successfully")
});

document.getElementById('noButton').addEventListener('click', function() {
  console.log("User clicked No.");
  hideCustomModal();
  // Handle cancellation
});
// Trigger the custom modal
showCustomModal();
 
}

$(document).ready(function () {
  
  // Fetch Pokémon data and initialize
  fetchPokemonData();
 
  // Event listeners
  $("#pokemonTypeFilter").on("change", handleTypeFilterChange);
  $(".ability-checkbox").on("change", handleAbilityCheckboxChange);
  $("#add-row-btn").on("click", addRowModal);
  $("#save-new-row").on("click", saveNewPokemon);
  $("#cancel-new-row").on("click", cancelAddRowModal);
  $(".dropdown-btn").on("click", toggleAbilitiesDropdown);
  $("#cancel-edit-row").on("click", function () {
    $("#edit-row-modal").hide(); // Simply close the modal without saving
  });
});
